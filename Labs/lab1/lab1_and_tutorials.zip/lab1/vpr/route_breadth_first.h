boolean try_breadth_first_route (struct s_router_opts router_opts, 
             t_ivec **clb_opins_used_locally); 
