// hello.cpp -- "Hello, world" C++ program

using namespace std;
#include <iostream>

int main () {

    cout << "Hello " << endl;
    cout << "world!" << endl;
    return (0);
}

