#include <iostream>

using namespace std;

int main(int argc,char **argv)
{
    string name;
    cout << "Please type your name: ";
    cin >> name;

    cout << "Hello, " << name << ", and welcome to ECE244" << endl;
    return 0;
}
